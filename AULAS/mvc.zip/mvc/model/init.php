<?php

//timezone

date_default_timezone_set('America/Sao_Paulo');

// conexão com o banco de dados

define('BD_SERVIDOR','localhost');
define('BD_USUARIO','id18836643_mvc');
define('BD_SENHA','^WYp@m0>Oo4PZ~U?');
define('BD_BANCO','id18836643_livraria');